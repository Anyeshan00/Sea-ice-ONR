clc
clear, close all

%% parameter initializations in arrays
fs= [0.3 1 3]*1e6;
e1s= [23.5 12 8.5];
e2s= [80];
lt1s= [1.8 1.41 0.82];
lt2s= [1863];
rhos= 1:20;
z= 2;
thicknesses= [2];
datatitle= {'frequency','epsilon1_ice', 'epsilon_water', 'tand_ice',  'tand_water', ...
    'thickness', 'rho', 'z', 'magEz', 'angEz', 'magHz', 'angHz'} 


%% parameter inputs
datacount=2;
for f= fs
    for e2= e2s
        for lt2= lt2s    
            for e1= e1s
                for lt1= lt1s
                    epsilon= [ 1 e1 e2];
                    mu= [1 1 1];
                    losst= [ 0 lt1 lt2];
                    for thickness= thicknesses
                        d= [0 thickness]
                        for rho = rhos
                            [Ez, Hz]= calculate_EzHz (f, epsilon, mu, losst , thickness, rho, z);
                            data(datacount,:)= [f, e1, e2, lt1, lt2, thickness, ...
                            rho, z, abs(Ez), angle(Ez)*180/pi, abs(Hz), angle(Hz)*180/pi];
                            datacount = datacount+1
                        end
                    end
                end
            end
        end
    end
end

               
%% opening the excel workbook
filename= 'data_Ez_Hz_3layer_.xlsx'
xlswrite (filename, datatitle,'sheet1', 'A1')
xlswrite (filename, (data),'sheet1', 'A2')
disp ('data exported')

