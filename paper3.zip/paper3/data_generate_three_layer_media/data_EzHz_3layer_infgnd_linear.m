clc
clear, close all

%% parameter initializations in arrays
fs= [0.1:0.1:2]*1e6;
f_lim= [fs(1) fs(end)]

e1s= (5:5:40); % the dielectric constant of the material at the lower frequency

e2s= [1];
lt1s= [0];
lt2s= [500];
rhos= 2:0.2:20;
z= 2;
thicknesses= [1:6];
datatitle= {'frequency','epsilon1', 'epsilon2',...
    'thickness', 'rho', 'z', 'magEz', 'angEz', 'magHz', 'angHz'} 

datasize= length(fs)*length (e1s)*length (e2s)*length (lt1s)*length (lt2s)...
    *length (rhos)*length (thicknesses);
%% parameter inputs
datacount=2;
for f= fs
    for e2= e2s
        for lt2= lt2s    
            for e1temp= e1s
                e1= interp1 (f_lim, [e1temp 0.8*e1temp], f ) %linear interpolation of epsilon
                for lt1= lt1s
                    epsilon= [ 1 e1 e2];
                    mu= [1 1 1];
                    losst= [ 0 lt1 lt2];
                    for thickness= thicknesses
                        d= [0 thickness];
                        for rho = rhos
                            [Ez, Hz]= calculate_EzHz (f, epsilon, mu, losst , thickness, rho, z);
                            data(datacount,:)= [f, e1, e2, thickness, ...
                            rho, z, abs(Ez), angle(Ez)*180/pi, abs(Hz), angle(Hz)*180/pi];
                            datacount = datacount+1;
                            disp ([num2str(datacount) ' out of ' num2str(datasize) ' completed'])
                        end
                    end
                end
            end
        end
    end
end

               
%% opening the excel workbook
filename= 'data_Ez_Hz_3layer_infgnd_linear.xlsx'
xlswrite (filename, datatitle,'sheet1', 'A1')
xlswrite (filename, (data),'sheet1', 'A2')
disp ('data exported')

