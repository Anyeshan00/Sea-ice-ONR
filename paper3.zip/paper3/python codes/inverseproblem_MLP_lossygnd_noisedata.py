#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd

import math
from math import log10, sqrt

import scipy.io
from scipy.io import loadmat

import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, Conv1D, MaxPooling1D, GlobalMaxPooling1D

from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error as mae

import matplotlib.pyplot as plt


# In[2]:


datapath= r'F:\ANYESHAN\paper3\datasets'
data_train= r'data_Ez_Hz_3layer_lossygnd_linear'

print (f'{datapath}\{data_train}.mat')
database= loadmat (f'{datapath}\{data_train}')


# In[3]:


def add_noise (data, powerdBs):
  """ This function adds data to a given data set and sends back the noisy dataset
  power dB is a 2d list input, with each row as the noisepower value of Ez and Hz"""
  noisydatas= data.copy(); 
  samples, datalen = noisydatas.shape
  dummyzero= np.zeros (samples)
  dummyzero= np.expand_dims(dummyzero, axis=1)
  for powerdB in powerdBs:
    powerdBEz= powerdB[0]
    powerdBHz= powerdB[1]
    npowerEz= 10** (powerdBEz/10)   
    npowerHz= 10** (powerdBHz/10)   
    noiseEz= np.random.normal(0, sqrt(npowerEz), (samples, (datalen-1)//2))
    noiseHz= np.random.normal(0, sqrt(npowerHz), (samples, (datalen-1)//2))
    noise= np.concatenate ((dummyzero, noiseEz, noiseHz), axis=1) ## adds no noise to frequency, adds Ez noise to Ez, adds Hz noise to Hz
    noisydata= data+noise
    noisydatas = np.concatenate((noisydatas, noisydata),axis=0)
  noisydatas= noisydatas [samples:,:]
  return noisydatas


# In[4]:


## targets
data_output= np.array(database['outputs_NN1'])
targets= (data_output [:,1:4]) #selectring the thickness and the dielectric property as targets


# In[5]:


# print (targets)


# In[6]:


#features
data_inputEz= np.array(database['input_Ez_mag'])
data_inputHz= np.array(database['input_Hz_mag'])
freq = data_output[:,0] #frequency will be given as the input column
freq=  np.expand_dims(freq, axis=1)
data_input= np.concatenate((freq, data_inputEz, data_inputHz), axis=1)


# In[7]:


# dividing the input data into training and testing set
data_train, data_test, target_train, target_test= train_test_split(data_input, targets, test_size = .1)


# In[8]:


# print(target_test)


# In[9]:


# adding the training data with noise
noise_arraydB= [[-40, -100], [-50, -110], [-60, -120], [-70, -130], [-80, -140]]
# noise_arraydB= [[-150,-200]]
noisydatatrain= add_noise(data_train, noise_arraydB)


# In[10]:


## creating the same number of copies for the target data in training
noisytargettrain= target_train
for idx in range (1, np.shape(noise_arraydB)[0]):
  noisytargettrain= np.concatenate ((noisytargettrain,target_train ), axis=0)


# In[11]:


print(noisytargettrain.shape)
print(noisydatatrain.shape)


# In[12]:


## normalization of the training data, specially the frequency
mean_in= noisydatatrain.mean(axis=0)
std_in = noisydatatrain.std(axis=0)
noisydatatrain_norm = (noisydatatrain -mean_in ) / std_in
n_feats = noisydatatrain_norm.shape[1] 


# In[13]:


## normalizing the noisy target values for training.
mean_out= noisytargettrain.mean(axis=0)
std_out = noisytargettrain.std(axis=0)
noisytargettrain_norm= (noisytargettrain - mean_out) / std_out 
features_output= targets.shape[1]


# In[14]:


def regression_model():
    # create model
    model = Sequential()
    model.add(Dense(256,  activation='relu', input_shape=(n_feats,)))
    model.add(Dense(512, activation='relu'))
    model.add(Dense(512, activation='relu'))
    model.add(Dense(1024, activation='relu'))
    model.add(Dense(1024, activation='relu'))
    model.add(Dense(1024, activation='relu'))
    model.add(Dense(features_output))
    
    # compile model
    model.compile(loss= 'mean_squared_error', optimizer='adam' , metrics= [ 'mae']) 
    return model


# In[15]:


from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, LearningRateScheduler, ReduceLROnPlateau
import keras
from keras.callbacks import EarlyStopping, ModelCheckpoint
file_path = "inverse_MLP.h5"
checkpoint = ModelCheckpoint(file_path, monitor='val_loss', verbose=1, save_best_only=True, mode='min')
early = EarlyStopping(monitor="val_loss", mode="min", patience=8, verbose=1)
redonplat = ReduceLROnPlateau(monitor="val_loss", mode="min", patience=5, verbose=2)
callbacks_list = [checkpoint, early, redonplat]  # early


# In[16]:


model_inverse = regression_model()
outputs = model_inverse.fit(noisydatatrain_norm, noisytargettrain_norm, validation_split=.1, callbacks= callbacks_list, epochs=100, verbose=True)


# In[17]:


outputs_dict= outputs.history

lossvals_train= outputs_dict ['loss']
lossvals_val= outputs_dict ['val_loss']
epochs= range (1, len(lossvals_train)+1)

plt. plot (epochs, lossvals_train, 'bo', label= 'Training Loss')
plt. plot (epochs, lossvals_val, 'b', label= 'Validation Loss')
plt. title ('Training and Validation loss')
plt.xlabel ('Epochs')
plt.ylabel ('Loss')
plt. legend()
plt.show()


# In[18]:


## Addding noise to the test data
noisetestdB= [[-80, -140]]

noisydatatest= add_noise (data_test, noisetestdB)
noisydatatest_norm = (noisydatatest -mean_in ) / std_in
#########################################


# In[19]:


target_pred = model_inverse.predict(noisydatatest_norm)*std_out+mean_out


# In[ ]:


#  print (target_test) 


# In[ ]:


# print (target_pred)


# In[20]:


## checking the error along each column of the target value
eps_1_test= target_test[:,0]
eps_2_test= target_test[:,1]
thickness_test= target_test[:,2]
# print (targets_test)


# In[21]:


eps_1_pred= target_pred[:,0]
eps_2_pred= target_pred[:,1]
thickness_pred= target_pred[:,2]
# print (targets_pred)


# In[22]:


mae_eps1= mae(eps_1_test, eps_1_pred)
mae_eps2= mae(eps_2_test, eps_2_pred)
mae_thickness= mae(thickness_test, thickness_pred)


# In[23]:


def percentage_error(actual, predicted):
    res_per = np.empty(actual.shape)
    res_mae = np.empty(actual.shape)
    for j in range(actual.shape[0]):
      res_per[j] = (actual[j] - predicted[j]) / actual[j]
      res_mae[j] = (actual[j] - predicted[j]) 
    # print (res_per)
    # print (res_mae)
    return res_per, res_mae

def mean_absolute_percentage_error(y_true, y_pred): 
    y1, y2=  percentage_error(np.asarray(y_true), np.asarray(y_pred))
    y_per=  np.mean(np.abs(y1)) * 100
    y_mae=  np.mean(np.abs(y2))
    return y_per, y_mae


# In[24]:


pe_e1, mae_e1= mean_absolute_percentage_error(eps_1_test, eps_1_pred)
pe_e2, mae_e2= mean_absolute_percentage_error(eps_2_test, eps_2_pred)
pe_h, mae_h= mean_absolute_percentage_error(thickness_test, thickness_pred)


# In[25]:


print (mae_e1, mae_e2, mae_h)


# In[26]:


print (pe_e1,pe_e2, pe_h)


# In[ ]:




