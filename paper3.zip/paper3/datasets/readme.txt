Please download

data_Ez_Hz_3layer_infgnd_lossy.mat

and

data_Ez_Hz_3layer_lossygnd_linear.mat

and save these data in this folder