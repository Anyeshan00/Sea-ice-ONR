function HED_freq_Hz_TGRS

% paper: Low-frequency near-field interferometry for characterization of 
% lossy dielectric and an investigation on sea ice

% does the frequency sweep in the near field, for fig 7.

%%
clc
clear, close all
tic,

%% initializations (Please change the variables according to the paper)
f_def= 1e6; % the freuquency at which the loss tangents are defined
w_def= 2*pi*f_def;
lambda= 3e8/f_def;
e0= 8.854e-12;
u0= pi*4e-7;

e1= 3.2; 
epsr= [ 1 e1 1]*e0; 
mu= [ 1 1 1]*u0;
LT1= 5;
losst= [ 0 LT1 5000]; 
sigma= losst.*epsr*w_def;
rho=5; % a chosen  radial distance of the reciever from the source for plot
I = 1;
len=1;
z=2;
%%

delfreq= .5e6; % the interval of the  frequency sweep
freq_init=0.1e6; %inital point, 100Khz
freq_end=50e6; % end point,  50 MHz
% the investigation  region is such that the wavelenght is  always much
% larger than  the  thickness

d_array= [ 1 2.5 5];
for dd= 1:length(d_array)
    d =  d_array(dd);
    disp(['calculating frequency sweep for thickness = ' num2str(d) 'm']) 
    count=1;
    for f= freq_init:delfreq:freq_end        
        w=2*pi*f;
        lambda= 3e8/f;            
        losst= sigma./(epsr*w);
        
        k= w*sqrt(u0.*e0);
        
        constETM= 1i*I*len/(4*pi*w*e0);
        constHTM= I*len/(4*pi);
        constETE= I*len*w*u0/(4*pi);
        constHTE= 1i*I*len/(4*pi);

        %% definition of the integral path ( Shifat) Along the sommerfeld path , with krhoi and delkrho as function of rho;
        delkrho= 0.05/rho;
        tol= 1e-6; % tolerance of convergence
        
        %% Determining Hz
        krho= -.01i/rho;
        sumIntegrandHz= 0;
        err= Inf;
        flag=3;
        datapoint=0;
        while( err >tol)
            temp= sumIntegrandHz;
            %term 1
            kz= sqrt(k.^2- krho^2);
            J= besselj(1, krho*rho);
            [~, R_TE] = planewave_response_TGRS(f,epsr/e0, mu/u0,sigma,[0 d], krho);
            term1= Hz(krho,kz(1),J,R_TE,z);
            %term 2
            kz= sqrt(k.^2- (krho+delkrho)^2);
            J= besselj(1, (krho+delkrho)*rho);
            [~, R_TE] = planewave_response_TGRS(f,epsr/e0, mu/u0,sigma,[0 d], krho+delkrho);
            term2= Hz(krho+delkrho,kz(1),J,R_TE,z);
            %passing in simpsons routine
            [sum, flag]= simpsons_routine(datapoint,term1, term2, flag);
            sumIntegrandHz= sumIntegrandHz+sum;
            err= abs((temp-sumIntegrandHz)/sumIntegrandHz);
            krho= krho+delkrho;
            datapoint= datapoint+1;
        end
        Hz_simpsons(count)=constHTE*sumIntegrandHz*delkrho/3;     
        count= count+1;
        
    end  
    semilogy(freq_init:delfreq:freq_end,abs(Hz_simpsons),'linewidth', 1.6);
    title('Hz Simpsons')
    hold on
    grid on
end
legend([num2str(transpose(d_array))]) ;
disp (['completed. time elapsed= ' num2str(toc) 's'])
end

function y=Hz (krho,kz,J,R_TE,z)
y=(krho^2/kz)*(1+R_TE)*J*exp(1i*kz*z);
end

function y= Ez(krho,kz,J,R_TM,z)
y= krho^2 *(1-R_TM)*J* exp(1i*kz*z);
end

function [sum, flag]= simpsons_routine(pointval,term1, term2, flag)
if (pointval==0);
    sum= term1+term2;
else
    sum= flag*term1 +term2;
    if flag==3
        flag=1;
    elseif flag==1
        flag=3;
    else
        disp ('Wrong flagging')
    end
end
end

