clc
clear, close all

%% define the input parameters
% for the data file
datatypes= ['lambda ', 'T_ice ', 'T_water ', 'S_ice ', 'S_water ', 'eps_ice ',...
    'eps_water ', 'tand_ice ', 'tand_water ', 'scale '];

%% for test data
savefilename_temp= 'dataset_scaled_analytictest_COMSOLparam.mat'
% frequency bands = 0.4 0.8 1.2 1.6 2.0 [2.3e6: 0.5e6: 4.8e6] % the lower scale , by a factor of 6
% 9 13 17 21 25% the upper band, the high frequency limits
frequency_array= 25.0e6;
savefilename= strcat(savefilename_temp, num2str(frequency_array/1e6), '.mat')

T_ice_array= -20;
T_water_array= [3];
S_ice_array= [4];
S_water_array= [15];
thickness_len= 4;
scale_min= 0.02;
scale_max= 0.04; % the limits of the maximum and the minimum thickness of the system (empirical)
% % for test data1 with the thickness inside the reaining range 0.007 , 0.003

%%

interval= (scale_max-scale_min)/(thickness_len-1);
scale_array= scale_min:interval:scale_max;

datasize= length (frequency_array)* length(T_ice_array)* length (T_water_array)...
    * length (S_ice_array) * length ( S_water_array)* thickness_len

pause(1)

%% data generation
datacount = 1;
for frequency = frequency_array
    lambda= 3e8/ frequency;
    z= 0.05*lambda; % wavelength scaled height of the reciever, for the train  dataset 3, the height is 
    %0.05 lambda
    rho_array= (0.01:0.002:0.05)*lambda; %wavelength scaled radial sweep
%     rho_array= 2:0.2:20; % fixed radial sweep
    for T_water= T_water_array
        for S_water = S_water_array
            for S_ice= S_ice_array % determination of sea ice epsilon and tandelta through interpolation
                for T_ice= T_ice_array
                    [epsr, tand]= dielectric_3_layered(frequency, T_ice, S_ice, T_water, S_water);
                    mu= [1 1 1];
%                     input('')
                    % defining epsilon and loss tangent input
                    % thickenss is a choice of random numbers
        % instead of defining the thickness, we estimate the scaling
        % thickness/lambda
                    for scale = scale_array
                        thickness= lambda*scale;
                        c_rho=1;
                        for rho = rho_array
                            [Ez(c_rho), Hz(c_rho)]=calculate_EzHz_seaice_water (frequency, epsr, mu, tand , thickness, rho, z);
                            c_rho= c_rho+1;
                        end
                        data(datacount,:)= [lambda, T_ice, T_water, S_ice, S_water, epsr(2),...
                            epsr(3), tand(2), tand(3), scale];
  
                        Ez_mag (datacount,:)= abs(Ez)*lambda^2; %normalized to wavelength
                        Hz_mag (datacount,:)= abs(Hz)*lambda^2; %normalized to wavelength

                        datacount= datacount+1
                    end
                    
                end
            end
        end
    end
end

save(strcat('F:\ANYESHAN\paper4\Dataset Paper\analytical datasets\fixed',savefilename),'datatypes','data', 'Ez_mag','Hz_mag' ) 
disp ('data exported')           
              

    
