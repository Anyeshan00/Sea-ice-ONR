function [eps, tand]= dielectric_3_layered(frequency, T_ice, S_ice, T_water, S_water)


%% interpolatd the values at particular frequncy, termperature and salinity values

% frequency=  1e6;
% T_ice= -25;
% S_ice= 4.4;
% T_water= -5;
% S_water= 20;

%% generate dielectric properties for sea water
[eps_water, tand_water]= calculate_seawater_epsilon(frequency,T_water,S_water);

%% load the epsilon and tandelta data

eps_ice= load ('epsilon_ice.mat');
eps_ice= eps_ice.eps;
tand_ice= load('losstangent_ice.mat');
tand_ice= tand_ice.tand;
f= eps_ice(1,:);

%% temperature and slainity variables
T= [-10 -35];
s= [5.16 2.2];
%% interpoltion at frequency
eps_ice_f= [   interp1(f, eps_ice(2,:), frequency) ... %s1, T1
    interp1(f, eps_ice(3,:), frequency) ... % s2, T1
    interp1(f, eps_ice(4,:), frequency) ... % s1, T2
    interp1(f, eps_ice(5,:), frequency)]; % s2, T2

tand_ice_f= [   interp1(f, tand_ice(2,:), frequency) ... %s1, T1
    interp1(f, tand_ice(3,:), frequency) ... % s2, T1
    interp1(f, tand_ice(4,:), frequency) ... % s1, T2
    interp1(f, tand_ice(5,:), frequency)]; % s2, T2

%% interpolation at salinity
eps_ice_s= [interp1(s, eps_ice_f(1:2), S_ice) ... % for s1
    interp1(s, eps_ice_f(3:4), S_ice)]; % for s2
tand_ice_s= [interp1(s, tand_ice_f(1:2), S_ice) ... % for s1
    interp1(s,tand_ice_f(3:4), S_ice)]; % for s2

%% interpolation at temperature
eps_ice_T= [interp1(T, eps_ice_s, T_ice)];
tand_ice_T= [interp1(T, tand_ice_s, T_ice)];


%% generate the dielctric properties of the three layered media
eps= [ 1 eps_ice_T eps_water ];
tand = [ 0 tand_ice_T tand_water];

end
