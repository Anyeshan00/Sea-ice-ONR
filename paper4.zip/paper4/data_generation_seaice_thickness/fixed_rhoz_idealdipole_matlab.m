function out = model
%
% fixed_rhoz_idealdipole_matlab.m
%
% Model exported on Jan 23 2022, 15:39 by COMSOL 5.5.0.292.

import com.comsol.model.*
import com.comsol.model.util.*

model = ModelUtil.create('Model');

model.modelPath('F:\ANYESHAN\Simulation files\comsol\Air_ice_water_system');

model.label('fixed_rhoz_idealdipole_matlab.mph');

model.param.set('f', '1e6');
model.param.set('lambda', '3e8[m/s]/f[Hz]');
model.param.set('offset', '-6[m]');
model.param.set('dim', '26[m]');
model.param.set('rec_height', '2[m]');
model.param.set('inf_space', '8[m]');
model.param.set('PML', '3[m]');
model.param.set('e0', '8.854e-12');
model.param.set('mu0', '4*3.1416*10e-7');
model.param.set('eps_0', '1');
model.param.set('eps_1', '18.7');
model.param.set('eps_2', '82.3');
model.param.set('losst_1', '1.5', 'loss tangent of the substrate');
model.param.set('losst_2', '1446');
model.param.set('sigma_0', '0');
model.param.set('sigma_1', '2*3.1416*e0*eps_1*f*losst_1');
model.param.set('sigma_2', '2*3.1416*e0*eps_2*f*losst_2');
model.param.set('rho_init', '3[m]');
model.param.set('rho_end', '15[m]');
model.param.set('sub_thick', '2[m]');

model.component.create('comp1', true);

model.component('comp1').geom.create('geom1', 3);

model.component('comp1').mesh.create('mesh1');

model.component('comp1').geom('geom1').create('blk1', 'Block');
model.component('comp1').geom('geom1').feature('blk1').label('substrate(ice)');
model.component('comp1').geom('geom1').feature('blk1').set('selresult', true);
model.component('comp1').geom('geom1').feature('blk1').set('color', '10');
model.component('comp1').geom('geom1').feature('blk1').set('pos', {'offset' 'offset' '-sub_thick'});
model.component('comp1').geom('geom1').feature('blk1').set('size', {'dim' 'dim' 'sub_thick'});
model.component('comp1').geom('geom1').feature('blk1').set('layername', {'Layer 1'});
model.component('comp1').geom('geom1').feature('blk1').setIndex('layer', 'PML', 0);
model.component('comp1').geom('geom1').feature('blk1').set('layerleft', true);
model.component('comp1').geom('geom1').feature('blk1').set('layerright', true);
model.component('comp1').geom('geom1').feature('blk1').set('layerfront', true);
model.component('comp1').geom('geom1').feature('blk1').set('layerback', true);
model.component('comp1').geom('geom1').feature('blk1').set('layerbottom', false);
model.component('comp1').geom('geom1').create('blk2', 'Block');
model.component('comp1').geom('geom1').feature('blk2').label('Air');
model.component('comp1').geom('geom1').feature('blk2').set('selresult', true);
model.component('comp1').geom('geom1').feature('blk2').set('color', 'custom');
model.component('comp1').geom('geom1').feature('blk2').set('customcolor', [1 0.9960784316062927 1]);
model.component('comp1').geom('geom1').feature('blk2').set('pos', {'offset' 'offset' '0'});
model.component('comp1').geom('geom1').feature('blk2').set('size', {'dim' 'dim' 'inf_space'});
model.component('comp1').geom('geom1').feature('blk2').set('layername', {'Layer 1'});
model.component('comp1').geom('geom1').feature('blk2').setIndex('layer', 'PML', 0);
model.component('comp1').geom('geom1').feature('blk2').set('layerleft', true);
model.component('comp1').geom('geom1').feature('blk2').set('layerright', true);
model.component('comp1').geom('geom1').feature('blk2').set('layerfront', true);
model.component('comp1').geom('geom1').feature('blk2').set('layerback', true);
model.component('comp1').geom('geom1').feature('blk2').set('layerbottom', false);
model.component('comp1').geom('geom1').feature('blk2').set('layertop', true);
model.component('comp1').geom('geom1').create('blk3', 'Block');
model.component('comp1').geom('geom1').feature('blk3').label('Ground(water)');
model.component('comp1').geom('geom1').feature('blk3').set('selresult', true);
model.component('comp1').geom('geom1').feature('blk3').set('color', 'custom');
model.component('comp1').geom('geom1').feature('blk3').set('customcolor', [0.054901961237192154 0.125490203499794 0.8588235378265381]);
model.component('comp1').geom('geom1').feature('blk3').set('pos', {'offset' 'offset' '-sub_thick-inf_space'});
model.component('comp1').geom('geom1').feature('blk3').set('size', {'dim' 'dim' 'inf_space'});
model.component('comp1').geom('geom1').feature('blk3').set('layername', {'Layer 1'});
model.component('comp1').geom('geom1').feature('blk3').setIndex('layer', 'PML', 0);
model.component('comp1').geom('geom1').feature('blk3').set('layerleft', true);
model.component('comp1').geom('geom1').feature('blk3').set('layerright', true);
model.component('comp1').geom('geom1').feature('blk3').set('layerfront', true);
model.component('comp1').geom('geom1').feature('blk3').set('layerback', true);
model.component('comp1').geom('geom1').create('pt1', 'Point');
model.component('comp1').geom('geom1').feature('pt1').label('source_dipole');
model.component('comp1').geom('geom1').create('ls1', 'LineSegment');
model.component('comp1').geom('geom1').feature('ls1').label('Endfire');
model.component('comp1').geom('geom1').feature('ls1').set('specify1', 'coord');
model.component('comp1').geom('geom1').feature('ls1').set('coord1', {'rho_init' '0' 'rec_height'});
model.component('comp1').geom('geom1').feature('ls1').set('specify2', 'coord');
model.component('comp1').geom('geom1').feature('ls1').set('coord2', {'rho_end' '0' 'rec_height'});
model.component('comp1').geom('geom1').create('ls2', 'LineSegment');
model.component('comp1').geom('geom1').feature('ls2').label('Broadside');
model.component('comp1').geom('geom1').feature('ls2').set('specify1', 'coord');
model.component('comp1').geom('geom1').feature('ls2').set('coord1', {'0' 'rho_init' 'rec_height'});
model.component('comp1').geom('geom1').feature('ls2').set('specify2', 'coord');
model.component('comp1').geom('geom1').feature('ls2').set('coord2', {'0' 'rho_end' 'rec_height'});
model.component('comp1').geom('geom1').create('sph1', 'Sphere');
model.component('comp1').geom('geom1').feature('sph1').set('selresult', true);
model.component('comp1').geom('geom1').feature('sph1').set('r', '1[m]');
model.component('comp1').geom('geom1').run;

model.component('comp1').material.create('mat1', 'Common');
model.component('comp1').material.create('mat2', 'Common');
model.component('comp1').material.create('mat3', 'Common');
model.component('comp1').material('mat1').selection.set([4 5 9 10 14 15 19 20 24 25 29 30 36 37 41 42 46 47]);
model.component('comp1').material('mat2').selection.set([3 8 13 18 23 28 31 32 35 40 45]);
model.component('comp1').material('mat3').selection.set([1 2 6 7 11 12 16 17 21 22 26 27 33 34 38 39 43 44]);

model.component('comp1').coordSystem.create('pml1', 'PML');
model.component('comp1').coordSystem('pml1').selection.set([1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 25 26 27 28 29 30 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47]);

model.component('comp1').physics.create('emw', 'ElectromagneticWaves', 'geom1');
model.component('comp1').physics('emw').create('epd1', 'ElectricPointDipole', 0);
model.component('comp1').physics('emw').feature('epd1').selection.set([52]);
model.component('comp1').physics('emw').create('sctr1', 'Scattering', 2);
model.component('comp1').physics('emw').feature('sctr1').selection.all;

model.component('comp1').mesh('mesh1').create('ftet1', 'FreeTet');
model.component('comp1').mesh('mesh1').create('ftet2', 'FreeTet');
model.component('comp1').mesh('mesh1').create('ftet3', 'FreeTet');
model.component('comp1').mesh('mesh1').create('swe1', 'Sweep');
model.component('comp1').mesh('mesh1').feature('ftet1').selection.geom('geom1', 3);
model.component('comp1').mesh('mesh1').feature('ftet1').create('size1', 'Size');
model.component('comp1').mesh('mesh1').feature('ftet1').feature('size1').selection.geom('geom1', 3);
model.component('comp1').mesh('mesh1').feature('ftet2').selection.geom('geom1', 3);
model.component('comp1').mesh('mesh1').feature('ftet2').selection.set([23 24 31 32]);
model.component('comp1').mesh('mesh1').feature('ftet2').create('size1', 'Size');
model.component('comp1').mesh('mesh1').feature('ftet3').selection.geom('geom1', 3);
model.component('comp1').mesh('mesh1').feature('ftet3').selection.set([22]);
model.component('comp1').mesh('mesh1').feature('ftet3').create('size1', 'Size');
model.component('comp1').mesh('mesh1').feature('swe1').create('dis1', 'Distribution');
model.component('comp1').mesh('mesh1').feature('swe1').create('size1', 'Size');
model.component('comp1').mesh('mesh1').feature('swe1').feature('dis1').selection.set([1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 25 26 27 28 29 30 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47]);

model.component('comp1').view('view1').set('scenelight', false);

model.component('comp1').material('mat1').label('Material 1(Air)');
model.component('comp1').material('mat1').propertyGroup('def').set('relpermittivity', {'eps_0' '0' '0' '0' 'eps_0' '0' '0' '0' 'eps_0'});
model.component('comp1').material('mat1').propertyGroup('def').set('relpermittivity_symmetry', '0');
model.component('comp1').material('mat1').propertyGroup('def').set('relpermeability', {'1' '0' '0' '0' '1' '0' '0' '0' '1'});
model.component('comp1').material('mat1').propertyGroup('def').set('relpermeability_symmetry', '0');
model.component('comp1').material('mat1').propertyGroup('def').set('electricconductivity', {'sigma_0' '0' '0' '0' 'sigma_0' '0' '0' '0' 'sigma_0'});
model.component('comp1').material('mat1').propertyGroup('def').set('electricconductivity_symmetry', '0');
model.component('comp1').material('mat2').label('Material 2 (Sea ice)');
model.component('comp1').material('mat2').propertyGroup('def').set('relpermittivity', {'eps_1' '0' '0' '0' 'eps_1' '0' '0' '0' 'eps_1'});
model.component('comp1').material('mat2').propertyGroup('def').set('relpermittivity_symmetry', '0');
model.component('comp1').material('mat2').propertyGroup('def').set('relpermeability', {'1' '0' '0' '0' '1' '0' '0' '0' '1'});
model.component('comp1').material('mat2').propertyGroup('def').set('relpermeability_symmetry', '0');
model.component('comp1').material('mat2').propertyGroup('def').set('electricconductivity', {'sigma_1' '0' '0' '0' 'sigma_1' '0' '0' '0' 'sigma_1'});
model.component('comp1').material('mat2').propertyGroup('def').set('electricconductivity_symmetry', '0');
model.component('comp1').material('mat3').label('Material 3 (Sea water)');
model.component('comp1').material('mat3').propertyGroup('def').set('relpermittivity', {'eps_2' '0' '0' '0' 'eps_2' '0' '0' '0' 'eps_2'});
model.component('comp1').material('mat3').propertyGroup('def').set('relpermittivity_symmetry', '0');
model.component('comp1').material('mat3').propertyGroup('def').set('relpermeability', {'1' '0' '0' '0' '1' '0' '0' '0' '1'});
model.component('comp1').material('mat3').propertyGroup('def').set('relpermeability_symmetry', '0');
model.component('comp1').material('mat3').propertyGroup('def').set('electricconductivity', {'sigma_2' '0' '0' '0' 'sigma_2' '0' '0' '0' 'sigma_2'});
model.component('comp1').material('mat3').propertyGroup('def').set('electricconductivity_symmetry', '0');

model.component('comp1').physics('emw').feature('epd1').set('enpI', [1; 0; 0]);
model.component('comp1').physics('emw').feature('epd1').set('normpI', 1);

model.component('comp1').mesh('mesh1').feature('size').set('custom', 'on');
model.component('comp1').mesh('mesh1').feature('size').set('hmax', 1.5);
model.component('comp1').mesh('mesh1').feature('size').set('hmin', 0.3);
model.component('comp1').mesh('mesh1').feature('size').set('hgrad', 1.25);
model.component('comp1').mesh('mesh1').feature('ftet1').label('mesh_pointdipole');
model.component('comp1').mesh('mesh1').feature('ftet1').feature('size1').set('custom', 'on');
model.component('comp1').mesh('mesh1').feature('ftet1').feature('size1').set('hmax', 1.5);
model.component('comp1').mesh('mesh1').feature('ftet1').feature('size1').set('hmaxactive', true);
model.component('comp1').mesh('mesh1').feature('ftet1').feature('size1').set('hmin', 0.3);
model.component('comp1').mesh('mesh1').feature('ftet1').feature('size1').set('hminactive', true);
model.component('comp1').mesh('mesh1').feature('ftet1').feature('size1').set('hcurve', 0.15);
model.component('comp1').mesh('mesh1').feature('ftet1').feature('size1').set('hcurveactive', true);
model.component('comp1').mesh('mesh1').feature('ftet1').feature('size1').set('hgrad', 1.1);
model.component('comp1').mesh('mesh1').feature('ftet1').feature('size1').set('hgradactive', true);
model.component('comp1').mesh('mesh1').feature('ftet2').label('Mesh_air_sub');
model.component('comp1').mesh('mesh1').feature('ftet2').feature('size1').set('hauto', 1);
model.component('comp1').mesh('mesh1').feature('ftet2').feature('size1').set('custom', 'on');
model.component('comp1').mesh('mesh1').feature('ftet2').feature('size1').set('hmax', 1.5);
model.component('comp1').mesh('mesh1').feature('ftet2').feature('size1').set('hmaxactive', true);
model.component('comp1').mesh('mesh1').feature('ftet2').feature('size1').set('hmin', 0.1);
model.component('comp1').mesh('mesh1').feature('ftet2').feature('size1').set('hminactive', true);
model.component('comp1').mesh('mesh1').feature('ftet2').feature('size1').set('hgrad', 1.2);
model.component('comp1').mesh('mesh1').feature('ftet2').feature('size1').set('hgradactive', true);
model.component('comp1').mesh('mesh1').feature('ftet3').label('Mesh_remaining');
model.component('comp1').mesh('mesh1').feature('ftet3').feature('size1').set('hauto', 1);
model.component('comp1').mesh('mesh1').feature('ftet3').feature('size1').set('custom', 'on');
model.component('comp1').mesh('mesh1').feature('ftet3').feature('size1').set('hmax', 150);
model.component('comp1').mesh('mesh1').feature('ftet3').feature('size1').set('hmaxactive', true);
model.component('comp1').mesh('mesh1').feature('ftet3').feature('size1').set('hmin', 0.3);
model.component('comp1').mesh('mesh1').feature('ftet3').feature('size1').set('hminactive', true);
model.component('comp1').mesh('mesh1').feature('ftet3').feature('size1').set('hgrad', 1.5);
model.component('comp1').mesh('mesh1').feature('ftet3').feature('size1').set('hgradactive', true);
model.component('comp1').mesh('mesh1').feature('swe1').feature('dis1').set('numelem', 8);
model.component('comp1').mesh('mesh1').feature('swe1').feature('size1').set('custom', 'on');
model.component('comp1').mesh('mesh1').feature('swe1').feature('size1').set('hmax', 1);
model.component('comp1').mesh('mesh1').feature('swe1').feature('size1').set('hmaxactive', true);
model.component('comp1').mesh('mesh1').feature('swe1').feature('size1').set('hmin', 0.2);
model.component('comp1').mesh('mesh1').feature('swe1').feature('size1').set('hminactive', true);
model.component('comp1').mesh('mesh1').feature('swe1').feature('size1').set('hcurveactive', true);
model.component('comp1').mesh('mesh1').feature('swe1').feature('size1').set('hnarrow', 1);
model.component('comp1').mesh('mesh1').feature('swe1').feature('size1').set('hnarrowactive', true);
model.component('comp1').mesh('mesh1').feature('swe1').feature('size1').set('hgrad', 1.2);
model.component('comp1').mesh('mesh1').feature('swe1').feature('size1').set('hgradactive', true);
model.component('comp1').mesh('mesh1').run;

model.study.create('std1');
model.study('std1').create('freq', 'Frequency');

model.sol.create('sol1');
model.sol('sol1').study('std1');
model.sol('sol1').attach('std1');
model.sol('sol1').create('st1', 'StudyStep');
model.sol('sol1').create('v1', 'Variables');
model.sol('sol1').create('s1', 'Stationary');
model.sol('sol1').feature('s1').create('p1', 'Parametric');
model.sol('sol1').feature('s1').create('fc1', 'FullyCoupled');
model.sol('sol1').feature('s1').create('i1', 'Iterative');
model.sol('sol1').feature('s1').feature('i1').create('mg1', 'Multigrid');
model.sol('sol1').feature('s1').feature('i1').feature('mg1').feature('pr').create('sv1', 'SORVector');
model.sol('sol1').feature('s1').feature('i1').feature('mg1').feature('po').create('sv1', 'SORVector');
model.sol('sol1').feature('s1').feature('i1').feature('mg1').feature('cs').create('d1', 'Direct');
model.sol('sol1').feature('s1').feature.remove('fcDef');

model.result.dataset.create('cln1', 'CutLine3D');
model.result.dataset.create('cln2', 'CutLine3D');
model.result.create('pg1', 'PlotGroup1D');
model.result.create('pg2', 'PlotGroup1D');
model.result('pg1').create('lngr1', 'LineGraph');
model.result('pg1').feature('lngr1').set('expr', 'sqrt(realdot(emw.Ez,emw.Ez))');
model.result('pg2').create('lngr1', 'LineGraph');
model.result('pg2').feature('lngr1').set('expr', 'sqrt(realdot(emw.Hz,emw.Hz))');

model.study('std1').feature('freq').set('punit', 'Hz');
model.study('std1').feature('freq').set('plist', 'f');
model.study('std1').feature('freq').set('ngen', 5);

model.sol('sol1').attach('std1');
model.sol('sol1').feature('v1').set('clistctrl', {'p1'});
model.sol('sol1').feature('v1').set('cname', {'freq'});
model.sol('sol1').feature('v1').set('clist', {'f[Hz]'});
model.sol('sol1').feature('s1').set('stol', 0.01);
model.sol('sol1').feature('s1').set('plot', true);
model.sol('sol1').feature('s1').feature('aDef').set('complexfun', true);
model.sol('sol1').feature('s1').feature('p1').set('control', 'user');
model.sol('sol1').feature('s1').feature('p1').set('pname', {'freq'});
model.sol('sol1').feature('s1').feature('p1').set('plistarr', {'f'});
model.sol('sol1').feature('s1').feature('p1').set('punit', {'Hz'});
model.sol('sol1').feature('s1').feature('p1').set('pcontinuationmode', 'no');
model.sol('sol1').feature('s1').feature('p1').set('preusesol', 'auto');
model.sol('sol1').feature('s1').feature('p1').set('uselsqdata', false);
model.sol('sol1').feature('s1').feature('p1').set('plot', true);
model.sol('sol1').feature('s1').feature('i1').label('Suggested Iterative Solver (emw)');
model.sol('sol1').feature('s1').feature('i1').set('itrestart', 300);
model.sol('sol1').feature('s1').feature('i1').set('prefuntype', 'right');
model.sol('sol1').feature('s1').feature('i1').feature('mg1').set('iter', 1);
model.sol('sol1').feature('s1').feature('i1').feature('mg1').feature('cs').feature('d1').set('linsolver', 'pardiso');
model.sol('sol1').runAll;

model.result.dataset('cln1').label('endfire');
model.result.dataset('cln1').set('genpoints', {'rho_init' '0' 'rec_height'; 'rho_end' '0' 'rec_height'});
model.result.dataset('cln2').label('broadside');
model.result.dataset('cln2').set('genpoints', {'0' 'rho_init' 'rec_height'; '0' 'rho_end' 'rec_height'});
model.result('pg1').label('Endfire');
model.result('pg1').set('xlabel', 'Arc length (m)');
model.result('pg1').set('ylabel', 'sqrt(realdot(emw.Ez,emw.Ez)) (V/m)');
model.result('pg1').set('showgrid', false);
model.result('pg1').set('xlabelactive', false);
model.result('pg1').set('ylabelactive', false);
model.result('pg1').feature('lngr1').label('Ez');
model.result('pg1').feature('lngr1').set('data', 'cln1');
model.result('pg1').feature('lngr1').set('looplevelinput', {'all'});
model.result('pg1').feature('lngr1').set('resolution', 'normal');
model.result('pg2').label('Broadside');
model.result('pg2').set('xlabel', 'Arc length (m)');
model.result('pg2').set('ylabel', 'sqrt(realdot(emw.Hz,emw.Hz)) (A/m)');
model.result('pg2').set('xlabelactive', false);
model.result('pg2').set('ylabelactive', false);
model.result('pg2').feature('lngr1').label('Hz');
model.result('pg2').feature('lngr1').set('data', 'cln2');
model.result('pg2').feature('lngr1').set('looplevelinput', {'all'});
model.result('pg2').feature('lngr1').set('resolution', 'normal');

out = model;
