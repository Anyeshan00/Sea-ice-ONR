function y= remove_nan (x)
    x(isnan(x))=0;
    ind = find(sum(x,2)==0) ;
    x(ind,:) = [] ;
    y= x;
end
    