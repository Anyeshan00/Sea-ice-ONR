clc
clear, close all

%% define the input parameters
% for the data file
datatypes= ['lambda ', 'T_ice ', 'T_water ', 'S_ice ', 'S_water ', 'eps_ice ',...
    'eps_water ', 'tand_ice ', 'tand_water ', 'thickness '];
% xlswrite (datafilename, filetypes,'sheet1', 'A1');


%% training dataset
frequency_array= 2e6: 1e6: 5e6;
T_ice_array= -35:8:-10;
T_water_array= [2 5];
S_ice_array= [5.16 2.2];
S_water_array= [6.4,25.2];
thickness_len= 21;
thick_min= 0.75;
thick_max= 6; % the limits of the maximum and the minimum thickness of the system (empirical)
%for the training data
% thickness_array= 1: 0.25:6;

%% for test data
savefilename= 'dataset_fixed_COMSOLtest11.mat'
% frequency bands = 0.4 0.8 1.2 1.6 2.0 [2.3e6: 0.5e6: 4.8e6] % the lower scale , by a factor of 6
% 5.2 5.6 6 6.4 6.8 % the upper band, the high frequency limits
frequency_array= 6.8e6;
% frequency_array= 2.3e6: 1.25e6: 4.8e6;
T_ice_array= -25;
T_water_array= [4];
S_ice_array= [3];
S_water_array= [19];
thick_min= 1.5;
thick_max= 5;
thickness_len= 4;

%%
interval= (thick_max-thick_min)/(thickness_len-1);
thick_array= thick_min:interval:thick_max;

datasize= length (frequency_array)* length(T_ice_array)* length (T_water_array)...
    * length (S_ice_array) * length ( S_water_array)* thickness_len

pause(5)
%% loading the comsol file
mod_com= mphload ('fixed_rhoz_idealdipole_matlab.mph')

%% data generation
datacount = 1;
for frequency = frequency_array
    lambda= 3e8/ frequency;
    mod_com.param.set('f', num2str(frequency)); %settting the frequency
    for T_water= T_water_array
        for S_water = S_water_array
            for S_ice= S_ice_array % determination of sea ice epsilon and tandelta through interpolation
                for T_ice= T_ice_array
                    [epsr, tand]= dielectric_3_layered(frequency, T_ice, S_ice, T_water, S_water);
                    %% setting the dielectric parameters inside comsol
                    mod_com.param.set('eps_0', num2str(epsr(1)));
                    mod_com.param.set('eps_1', num2str(epsr(2)));
                    mod_com.param.set('eps_2', num2str(epsr(3)));
                    mod_com.param.set('losst_1', num2str(tand(2)));
                    mod_com.param.set('losst_2', num2str(tand(3)));

                    % instead of defining the thickness, we estimate the scaling
                    % thickness/lambda
                    for thickness = thick_array
                        mod_com.param.set('sub_thick', num2str(thickness)); % setting the scale in comsol
                        
                        mod_com.sol('sol1').runAll; % run the file
 
                        data(datacount,:)= [lambda, T_ice, T_water, S_ice, S_water, epsr(2),...
                            epsr(3), tand(2), tand(3), thickness];
                        % epsr2 and eps3 are the dielectric constants of
                        % the sea ice and sea water respectively, same
                        % applies for tand 
                        
                        Ez= mphplot(mod_com,'pg1', 'createplot', 'off'); % the endfire plot
                        Ezdata= Ez{1,1}{1}.d;
                        Hz= mphplot(mod_com,'pg2', 'createplot', 'off'); % the broadside plot
                        Hzdata= Hz{1,1}{1}.d;
%                         Ez_mag (datacount,:)= Ezdata*lambda^2; %normalized to wavelength
%                         Hz_mag (datacount,:)= Hzdata*lambda^2; %normalized to wavelength
                        Ez_mag (datacount,:)= Ezdata; %not normalized to wavelength
                        Hz_mag (datacount,:)= Hzdata; %not normalized to wavelength
%                         Ez_angle (datacount,:)= unwrap(angle(Ez))*180/pi;
%                         Hz_angle (datacount,:)= unwrap(angle(Hz))*180/pi;
                        
                        datacount= datacount+1
                    end
                    
                end
            end
        end
    end
end
% xlswrite (datafilename, (data),'sheet1', 'A2') % writes the input data for radial sweep
% xlswrite (datafilename, Ez_mag,'sheet2', 'A1') % writes |Ez|
% xlswrite (datafilename, Hz_mag,'sheet3', 'A1') % writes |Hz|
% xlswrite (datafilename, Ez_angle,'sheet4', 'A1') % writes <Ez
% xlswrite (datafilename, Hz_angle,'sheet5', 'A1') % writes <Hz

save(strcat('E:\sea_ice_data\',savefilename),'datatypes','data', 'Ez_mag','Hz_mag' )

disp ('data exported')           
              

    
