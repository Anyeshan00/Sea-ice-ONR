%% creates a uniformly interpolated frequency dependent data of epsiln and tan delta from sea ice data

clc
clear, close all


%% load the data of sea ice
dataset_eps_s1= xlsread('E:\third year\2_full_demonstration_seaice_inverse\data_generation_seaice_thickness\sea_ice_epsilon.xlsx', 's1');
dataset_eps_s2= xlsread('E:\third year\2_full_demonstration_seaice_inverse\data_generation_seaice_thickness\sea_ice_epsilon.xlsx', 's2');
dataset_tand_s1= xlsread('E:\third year\2_full_demonstration_seaice_inverse\data_generation_seaice_thickness\sea_ice_tand.xlsx', 's1');
dataset_tand_s2= xlsread('E:\third year\2_full_demonstration_seaice_inverse\data_generation_seaice_thickness\sea_ice_tand.xlsx', 's2');
T1= -10;
T2= -35;
s1= 5.16;
s2= 2.2;

%% pre processing and generating the proper matrices
%epsilon
% salinity s1
A1= (dataset_eps_s1 (:,3:4)); % frequency vs epsilon data for T= -10
B1= (dataset_eps_s1 (:,6:7));   % frequency vs epsilon data for T= -35
%salinity s2
C1= (dataset_eps_s2 (:,3:4)); % frequency vs epsilon data for T= -10
D1= (dataset_eps_s2 (:,6:7));  % frequency vs epsilon data for T= -35
eps_T1{1}= remove_nan(A1);
eps_T2{1}=remove_nan(B1);
eps_T1{2} = remove_nan(C1);
eps_T2{2} = remove_nan(D1);
%tandelta
%sality s1
A2= (dataset_tand_s1 (:,3:4));
B2= (dataset_tand_s1 (:,6:7));
%salinity s2
C2= (dataset_tand_s2 (:,3:4));
D2= (dataset_tand_s2 (:,6:7));
tand_T1{1}= remove_nan(A2);
tand_T2{1}=remove_nan(B2);
tand_T1{2} = remove_nan(C2);
tand_T2{2} = remove_nan(D2);

% datasize= length (frequency_array)* length(T_ice_array)* length (T_water_array)...

%% data generation
datacount = 1;
% for frequency = frequency_array
%     for T_water= T_water_array
%         for S_water = S_water_array
% dileectric properties of sea water
%             for S_ice= S_ice_array % determination of sea ice epsilon and tandelta through interpolation
%% creating a uniform frequency vector for proper intepolation
f_array= (.2:0.2:3)*1e6;

%% epsilon at temperature t1

eps_t1_s1 = eps_T1{1} ;
eps_t1_s1= interp1(eps_t1_s1(:,1),eps_t1_s1(:,2), f_array);

eps_t1_s2 = eps_T1{2} ;
eps_t1_s2= interp1(eps_t1_s2(:,1),eps_t1_s2(:,2), f_array);


eps_t1= [ eps_t1_s1; eps_t1_s2];



%% epsilon at temperature t2

eps_t2_s1 = eps_T2{1} ;
eps_t2_s1= interp1(eps_t2_s1(:,1),eps_t2_s1(:,2), f_array);

eps_t2_s2 = eps_T2{2} ;
eps_t2_s2= interp1(eps_t2_s2(:,1),eps_t2_s2(:,2), f_array);


eps_t2= [ eps_t2_s1; eps_t2_s2];
%%
eps= [f_array; eps_t1 ; eps_t2];

%% tandelta at temperature t1

tand_t1_s1 = tand_T1{1} ;
tand_t1_s1= interp1(tand_t1_s1(:,1),tand_t1_s1(:,2), f_array);

tand_t1_s2 = tand_T1{2} ;
tand_t1_s2= interp1(tand_t1_s2(:,1),tand_t1_s2(:,2), f_array);

tand_t1= [ tand_t1_s1; tand_t1_s2];


%% epsilon at temperature t2

tand_t2_s1 = tand_T2{1} ;
tand_t2_s1= interp1(tand_t2_s1(:,1),tand_t2_s1(:,2), f_array);

tand_t2_s2 = tand_T2{2} ;
tand_t2_s2= interp1(tand_t2_s2(:,1),tand_t2_s2(:,2), f_array);


tand_t2= [tand_t2_s1; tand_t2_s2];

%%

tand= [f_array; tand_t1 ; tand_t2];

save('epsilon_ice.mat','eps')
save('losstangent_ice.mat','tand')

