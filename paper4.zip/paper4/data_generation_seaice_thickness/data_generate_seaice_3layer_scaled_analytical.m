clc
clear, close all

%% define the input parameters
% for the data file
datatypes= ['lambda ', 'T_ice ', 'T_water ', 'S_ice ', 'S_water ', 'eps_ice ',...
    'eps_water ', 'tand_ice ', 'tand_water ', 'scale '];


%% training dataset
savefilename= 'dataset_scaled_analytictrain_COMSOLparam.mat'
frequency_array= 2e6: 0.5e6: 5e6; % for training inside the measurement range
% frequency_array= 20e6: 0.5e6: 27e6; % for training outside the measurement range
T_ice_array= -35:8:-10;
T_water_array= [2 5 8];
% S_ice_array= [5.16 4.8 3.5 2.2];
S_ice_array= [5.16 2.2];
% S_water_array= [6.4,12.7,19.0,25.2];
S_water_array= [6.4,12.7,25.2];
thickness_len= 17; % for the test data, fro the training data the thickness length is 91
scale_min= 0.01;
scale_max= 0.06; % the limits of the maximum and the minimum thickness of the system (empirical)
% for training data with the thickness scaled from 0.002 to 0.05

%%
interval= (scale_max-scale_min)/(thickness_len-1);
scale_array= scale_min:interval:scale_max;

datasize= length (frequency_array)* length(T_ice_array)* length (T_water_array)...
    * length (S_ice_array) * length ( S_water_array)* thickness_len

pause(1)

%% data generation
datacount = 1;
for frequency = frequency_array
    lambda= 3e8/ frequency;
    z= 0.05*lambda; % wavelength scaled height of the reciever, for the train  dataset 3, the height is 
    %0.05 lambda
    rho_array= (0.01:0.002:0.05)*lambda; %wavelength scaled radial sweep
%     rho_array= 2:0.2:20; % fixed radial sweep
    for T_water= T_water_array
        for S_water = S_water_array
            for S_ice= S_ice_array % determination of sea ice epsilon and tandelta through interpolation
                for T_ice= T_ice_array
                    [epsr, tand]= dielectric_3_layered(frequency, T_ice, S_ice, T_water, S_water);
                    mu= [1 1 1];
%                     input('')
                    % defining epsilon and loss tangent input
                    % thickenss is a choice of random numbers
        % instead of defining the thickness, we estimate the scaling
        % thickness/lambda
                    for scale = scale_array
                        thickness= lambda*scale;
                        c_rho=1;
                        for rho = rho_array
                            [Ez(c_rho), Hz(c_rho)]=calculate_EzHz_seaice_water (frequency, epsr, mu, tand , thickness, rho, z);
                            c_rho= c_rho+1;
                        end
                        data(datacount,:)= [lambda, T_ice, T_water, S_ice, S_water, epsr(2),...
                            epsr(3), tand(2), tand(3), scale];
                        % epsr2 and eps3 are the dielectric constants of
                        % the sea ice and sea water respectively, same
                        % applies for tand 
                        Ez_mag (datacount,:)= abs(Ez)*lambda^2; %normalized to wavelength
                        Hz_mag (datacount,:)= abs(Hz)*lambda^2; %normalized to wavelength

                        datacount= datacount+1
                    end
                    
                end
            end
        end
    end
end


save(strcat('E:\sea_ice_data\',savefilename),'datatypes','data', 'Ez_mag','Hz_mag' ) 
disp ('data exported')           
              

    
