clc
clear, close all


%% define the input parameters
% for the data file
datatypes= ['lambda ', 'T_ice ', 'T_water ', 'S_ice ', 'S_water ', 'eps_ice ',...
    'eps_water ', 'tand_ice ', 'tand_water ', 'scale '];


%% training dataset
savefilename= 'dataset_scaled_COMSOLtrain_2.mat'
frequency_array= 2e6: 0.5e6: 5e6; % for train dataset 1, where the frequency is inside the mearuement range.
% frequency_array= 20e6: 2e6: 30e6; % for train dataset 2, frequency is outside the  measurement range.
T_ice_array= -35:8:-10;
T_water_array= [2 5 8];
S_ice_array= [5.16 2.2];
S_water_array= [6.4, 12.7, 25.2];
% thickness_array= 1: 0.25:6;
% for training set
thickness_len= 17;
scale_min= 0.01;
scale_max= 0.06; % the limits of the maximum and the minimum thickness of the system (empirical)
% for test data with the thicknes inside the training range: 0.07, 0.0025 
interval= (scale_max-scale_min)/(thickness_len-1);
scale_array= scale_min:interval:scale_max;

% for test data
savefilename= 'dataset_scaled_COMSOLtest11.mat'
%frequency bands = 0.4 0.8 1.2 1.6 2.0 [2.3e6: 0.5e6: 4.8e6] % the lower scale , by a factor of 6
%9 13 17 21 25% the upper band, the high frequency limits
frequency_array= 25e6;
frequency_array= 2.3e6: 1.25e6: 4.8e6;
T_ice_array= -20;
T_water_array= [3];
S_ice_array= [4];
S_water_array= [15];
thickness_len= 4;
scale_min= 0.02;
scale_max= 0.04; % the limits of the maximum and the minimum thickness of the system (empirical)
% for test data1 with the thickness inside the reaining range 0.007 , 0.003
interval= (scale_max-scale_min)/(thickness_len-1);
scale_array= scale_min:interval:scale_max;
%%

datasize= length (frequency_array)* length(T_ice_array)* length (T_water_array)...
    * length (S_ice_array) * length ( S_water_array)* thickness_len

pause(5)
%% loading the comsol file
mod_com= mphload ('wavelength_scale_idealdipole2_matlab.mph')

%% interpolation across the  radial range.
rho_init= 0.01;
rho_end= 0.05;
datapoints= 11;
delrho= (rho_end-rho_init)/(datapoints-1);
rho_interp= rho_init:delrho:rho_end;

%% data generation
datacount = 1;
for frequency = frequency_array
    lambda= 3e8/ frequency;
    mod_com.param.set('f', num2str(frequency)); %settting the frequency
    for T_water= T_water_array
        for S_water = S_water_array
            for S_ice= S_ice_array % determination of sea ice epsilon and tandelta through interpolation
                for T_ice= T_ice_array
                    [epsr, tand]= dielectric_3_layered(frequency, T_ice, S_ice, T_water, S_water);
                    %% setting the dielectric parameters inside comsol
                    mod_com.param.set('eps_0', num2str(epsr(1)));
                    mod_com.param.set('eps_1', num2str(epsr(2)));
                    mod_com.param.set('eps_2', num2str(epsr(3)));
                    mod_com.param.set('losst_1', num2str(tand(2)));
                    mod_com.param.set('losst_2', num2str(tand(3)));

                    % instead of defining the thickness, we estimate the scaling
                    % thickness/lambda
                    for scale = scale_array
                        thickness= lambda*scale;
                        mod_com.param.set('sub_thick', num2str(thickness)); % setting the scale in comsol
                        
                        mod_com.sol('sol1').runAll; % run the file
 
                        data(datacount,:)= [lambda, T_ice, T_water, S_ice, S_water, epsr(2),...
                            epsr(3), tand(2), tand(3), scale];
                        % epsr2 and eps3 are the dielectric constants of
                        % the sea ice and sea water respectively, same
                        % applies for tand 
                        
                        Ez= mphplot(mod_com,'pg1', 'createplot', 'off'); % the endfire plot
                        rhodata= Ez{1,1}{1}.p;
                        Ezdata= Ez{1,1}{1}.d;
                        Ezdata= interp1(rhodata,Ezdata,rho_interp); %interpolation to secure fix data points
                        
                        Hz= mphplot(mod_com,'pg2', 'createplot', 'off'); % the broadside plot
                        rhodata= Hz{1,1}{1}.p;
                        Hzdata= Hz{1,1}{1}.d;
                        Hzdata= interp1(rhodata,Hzdata,rho_interp); % interpolation to secure fix data point
                        
                        Ez_mag (datacount,:)= Ezdata*lambda^2; %normalized to wavelength
                        Hz_mag (datacount,:)= Hzdata*lambda^2; %normalized to wavelength
                        
                        datacount= datacount+1
                    end
                    
                end
            end
        end
    end
end

save(strcat('F:\ANYESHAN\paper4\Dataset Paper\analytical datasets\fixed',savefilename),'datatypes','data', 'Ez_mag','Hz_mag' ) % saving in a mat workspace file

disp ('data exported')           
              

    
