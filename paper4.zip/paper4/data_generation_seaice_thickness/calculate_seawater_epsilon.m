function [eps, loss_tangent]= calculate_seawater_epsilon(f,T,S)
%% determination of the debye parameters for sea water at temperatures above 0 degree celcius
% S= 25; % salinity value in ppt 
% T= 24; % temperature value in degrees celcius
% f= 1e9;
w= 2*pi*f; % the frequency of interest
e0= 8.854e-12;

e_ref= 87.134-1.949e-1*T -1.276e-2*T.^2 + 2.491e-4*T.^3;
sigma_ref= S.*(0.182521 -1.46192e-3 *S + 2.09324e-5*S.^2 - 1.2205e-7*S.^3);
tau_ref= 1.768e-11 - 6.086e-13 .*T + 1.104e-14*T.^2 -8.111e-17* T.^3;

a_ST= 1+ 1.613e-5*S.*T-3.656e-3*S + 3.210e-5*S.^2 - 4.232e-7*S.^3;
delT=  25-T;
beta_ST= 2.033e-2 + 1.266e-4*delT + 2.464e-6*delT.^2 - S.*(1.849e-5...
    -2.551e-7*delT + 2.551e-8*delT.^2);
b_ST= 1 + 2.282e-5 * S.*T - 7.638e-4 * S - 7.760e-6 * S.^2 + 1.105e-8* S.^3;

eps_s= e_ref.* a_ST;
sigma = sigma_ref.*exp(-delT.*beta_ST);
eps_inf= 4.9;
tau = tau_ref.* b_ST;
% f
% w*tau
% input('')
alpha= 0;

%% fit to the debye data
epsilon = eps_inf + (eps_s- eps_inf)./(1+ 1i*w*tau).^(1-alpha) -1i*sigma./(w*e0);
eps= real(epsilon);
loss_tangent= abs(imag(epsilon)/ real(epsilon));
end

