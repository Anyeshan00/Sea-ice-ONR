clc
clear, close all


%% define the input parameters
% for the data file
datatypes= ['lambda ', 'T_ice ', 'T_water ', 'S_ice ', 'S_water ', 'eps_ice ',...
    'eps_water ', 'tand_ice ', 'tand_water ', 'z ', 'thickness '];
% xlswrite (datafilename, filetypes,'sheet1', 'A1');


%% for the training data
savefilename= 'dataset_scaled_analytictrain.mat'
frequency_array= 2e6: 0.25e6: 5e6;
T_ice_array= -35:5:-15;
T_water_array= [2 5 8];
S_ice_array= [5.16 4.8 3.5 2.2];
S_water_array= [6.4,12.7, 25.2];
thick_min= 0.5;
thick_max= 7;
thickness_len= 61; % fro data training
z= 2; % height of the receiver fixed

%%
interval= (thick_max-thick_min)/(thickness_len-1);
thickness_array= thick_min:interval:thick_max;

datasize= length (frequency_array)* length(T_ice_array)* length (T_water_array)...
    * length (S_ice_array) * length ( S_water_array)* thickness_len

% pause(5)

%% data generation
datacount = 1;
for frequency = frequency_array
    lambda= 3e8/ frequency;
    
    rho_array= 3:0.2:15; % fixed radial sweep
    for T_water= T_water_array
        for S_water = S_water_array
            for S_ice= S_ice_array % determination of sea ice epsilon and tandelta through interpolation
                for T_ice= T_ice_array
                    [epsr, tand]= dielectric_3_layered(frequency, T_ice, S_ice, T_water, S_water);
                    mu= [1 1 1];
                    % defining epsilon and loss tangent input
                    % thickenss is a choice of random numbers
                    for thickness = thickness_array
                        c_rho=1;
                        for rho = rho_array
                            [Ez(c_rho), Hz(c_rho)]=calculate_EzHz_seaice_water (frequency, epsr, mu, tand , thickness, rho, z);
                            c_rho= c_rho+1;
                        end
                        data(datacount,:)= [lambda, T_ice, T_water, S_ice, S_water, epsr(2),...
                            epsr(3), tand(2), tand(3), z, thickness];
                        % epsr2 and eps3 are the dielectric constants of
                        % the sea ice and sea water respectively, same
                        % applies for tand 
                        Ez_mag (datacount,:)= abs(Ez);
                        Hz_mag (datacount,:)= abs(Hz);
                        datacount= datacount+1
                    end
                    
                end
            end
        end
    end
end

save(strcat('F:\ANYESHAN\paper4\Dataset Paper\analytical datasets\fixed',savefilename),'datatypes','data', 'Ez_mag','Hz_mag' )  % saving in a mat workspace file

disp ('data exported')           
              

    
