#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd

import math
from math import log10

import scipy.io
from scipy.io import loadmat
from scipy.io import savemat

import keras
import tensorflow as tf
from keras.models import Sequential
from keras.layers import Dense, Dropout, Conv1D, MaxPooling1D, GlobalMaxPooling1D
from keras import backend as K

from sklearn.model_selection import train_test_split

import matplotlib.pyplot as plt


# In[2]:


datapath= r'F:\ANYESHAN\paper4\Dataset Paper\comsol datasets\fixed'

data_train= r'dataset_fixed_COMSOLtrain'

print (f'{datapath}\{data_train}.mat')
database= loadmat (f'{datapath}\{data_train}')


# In[3]:


## creating a model save file name for writing the MODEL, and the variables
model_ext_fol= datapath.split("\\")[-1]
model_ext_file= data_train.split("_")[-1]
model= "inverse_d"
modelname= (f'{model}_{model_ext_fol}_{model_ext_file}.h5')
print(model_ext_fol)
print(model_ext_file)
print(modelname)


# In[4]:


# extraction of the  target features (non normalized)
data_target_extract= np.array(database['data']) 
datatypes =  np.array(database['datatypes']) 

## extracting the epsilon and the tand from the target dataset to add into the training  datasets
data_features_eps= data_target_extract[:,5:6]
data_features_tand= data_target_extract[:,7:8]
data_features_nonnorm= np.concatenate ((data_features_eps, data_features_tand), axis= 1) #the lambda value is not inserted as the input feature

data_target= data_target_extract[:,-1:]; # only the thickness as the output feature

# extracting the  frequency data from the output features
lamb= data_target_extract[:,0]
lamb=  np.expand_dims(lamb, axis=1) #dimension matching to concatenate with the input features
# extraction of the training features field values (non normalized)
data_features_E= np.array(database['Ez_mag']) 
data_features_H= np.array(database['Hz_mag']) 
## development of the feature dataset
data_features= np.concatenate ((lamb,data_features_E, data_features_H), axis= 1) # the lambda value is not inserted as the input feature
data_features.shape

## normalization of the training dataset
mean_in= data_features.mean(axis=0)
std_in = data_features.std(axis=0)
data_features_norm = (data_features -mean_in ) / std_in

## normalization of the target dataset
mean_out= data_target.mean(axis=0)
std_out = data_target.std(axis=0)
data_target_norm = (data_target -mean_out ) / std_out

## adding the non normalized epsilon and tandelta value to the normalized field values
data_features_train= np.concatenate ((data_features_nonnorm, data_features_norm), axis= 1)
n_feats = data_features_train.shape[1] 
print (n_feats)

## normalization of the target dataset
mean_out= data_target.mean(axis=0)
std_out = data_target.std(axis=0)
data_target_norm = (data_target -mean_out ) / std_out
n_targets= data_target_norm.shape[1]
print (n_targets)


# In[5]:


print(data_target)


# In[6]:


print (data_features_train)


# In[7]:


## saving the mean and std values in a variable which should be opened with  the training model
statfilename=  (f'statistics_{model_ext_fol}_{model_ext_file}_epstrain')
print (statfilename)


# In[8]:


stat_data= {"mean_in":mean_in, "std_in": std_in, "mean_out": mean_out, "std_out":std_out}
savemat(f'{datapath}\{statfilename}.mat',stat_data)


# In[9]:


## splitting the dataset into training and test set
features_train, A , target_train, B = train_test_split(data_features_train, data_target_norm, test_size=0.00001, random_state=0)


# In[10]:


## the deep learning layers
def regression_model():
    # create model
    model = Sequential()
    model.add(Dense(512,  activation='relu', input_shape=(n_feats,)))
    model.add(Dense(1024, activation='relu'))
    model.add(Dense(2048, activation='relu'))

    model.add(Dense(n_targets))
    opt = keras.optimizers.Adam(learning_rate=0.001)
    # compile model
    model.compile(loss= 'mean_squared_error', optimizer=opt , metrics= [ 'mae']) 
    return model

model_inverse = regression_model()


# In[11]:


from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, LearningRateScheduler, ReduceLROnPlateau
import keras
from keras.callbacks import EarlyStopping, ModelCheckpoint
file_path = (f'{datapath}\{modelname}')
checkpoint = ModelCheckpoint(file_path, monitor='val_loss', verbose=1, save_best_only=True, mode='min')
early = EarlyStopping(monitor="val_loss", mode="min", patience=8, verbose=1)
redonplat = ReduceLROnPlateau(monitor="val_loss", mode="min", patience=5, verbose=2)
callbacks_list = [checkpoint, early, redonplat]  # early


# In[12]:


outputs = model_inverse.fit(features_train,target_train,batch_size=16,callbacks=callbacks_list, validation_split=0.2, epochs=500,verbose=True)


# In[13]:


## plotting the loss values with epoch
outputs_dict= outputs.history

lossvals_train= outputs_dict ['loss']
lossvals_val= outputs_dict ['val_loss']
epochs= range (1, len(lossvals_train)+1)

plt. plot (epochs, lossvals_train, 'bo', label= 'Training Loss')
plt. plot (epochs, lossvals_val, 'b', label= 'Validation Loss')
plt. title ('Training and Validation loss')
plt.xlabel ('Epochs')
plt.ylabel ('Loss')
plt. legend()
plt.show()


# In[14]:


outputfilename = (f'outputs_{model_ext_fol}_{model_ext_file}_epstrain')

output_data= {"tr_loss":lossvals_train, "val_loss": lossvals_val}
savemat(f'{datapath}\{outputfilename}.mat',output_data)

