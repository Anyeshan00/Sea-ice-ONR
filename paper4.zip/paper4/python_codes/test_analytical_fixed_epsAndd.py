#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd

import math
from math import log10

import scipy.io
from scipy.io import loadmat

import keras
import tensorflow as tf
from keras.models import Sequential
from keras.models import load_model
from keras.layers import Dense, Dropout, Conv1D, MaxPooling1D, GlobalMaxPooling1D
from keras import backend as K

from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt


# In[2]:


datapath= r'F:\ANYESHAN\paper4\Dataset Paper\analytical datasets\fixed'
modelname= r'inverse_eps_d_fixed_analytictrain.h5'
statfilename= r'statistics_fixed_analytictrain.mat'

print (f'{datapath}\{modelname}')
print (f'{datapath}\{statfilename}')



# In[3]:


model_inv_epsd= load_model(f'{datapath}\{modelname}')
stats= loadmat (f'{datapath}\{statfilename}')


# In[4]:


mean_in= stats["mean_in"]
std_in= stats["std_in"]
mean_out= stats["mean_out"]
std_out= stats["std_out"]


# In[5]:


# loading the test files for checking losses in epsilon and ten delta
data_test= r'dataset_fixed_analytictest6.8.mat' # 

database_test= loadmat (f'{datapath}\{data_test}')


# In[6]:


data_target_test= np.array(database_test['data']) 
# extracting the  frequency data from the output features
freq_test= data_target_test[:,0]
freq_test=  np.expand_dims(freq_test, axis=1) #dimension matching to concatenate with the input features
data_target_test= np.column_stack((data_target_test [:,1:9] , data_target_test [:,-1:] )) # ignoring the constant value of z

# extraction of the training features (non normalized)
data_features_test_E= np.array(database_test['Ez_mag']) 
data_features_test_H= np.array(database_test['Hz_mag']) 
data_features_test= np.concatenate ((freq_test,data_features_test_E, data_features_test_H), axis= 1)

# normalization of the test dataset
data_features_test_norm = (data_features_test -mean_in ) / std_in
n_feats_test = data_features_test_norm.shape[1] 


# In[7]:


# apply model on the test feature dataset
# featueres: T_ice T_water S_ice S_water eps_ice eps_water tand_ice tand_water thickness
target_test_pred = model_inv_epsd.predict(data_features_test_norm)*std_out + mean_out

# observables, T_ice, S_ice, eps_ice, tand_ice, thickness
target_test_pred = np.column_stack(( target_test_pred [:,4],
                                 target_test_pred [:,6], target_test_pred [:,-1:] ))  # the prediction values
target_test = np.column_stack(( data_target_test[:,4],
                                 data_target_test [:,6], data_target_test [:,-1:] )) 


# In[8]:


print(target_test.shape[0])


# In[9]:


## checking various values and compare
idx= np.random.randint(target_test.shape[0], size=(5))
print (target_test_pred[idx])
np.set_printoptions(suppress=True)
print (target_test[idx])
np.set_printoptions(suppress=True)


# In[10]:


## functions for calculation of the percentage error
def percentage_error(actual, predicted):
    res_per = np.empty(actual.shape)
    res_mae = np.empty(actual.shape)
    for j in range(actual.shape[0]):
      res_per[j] = (actual[j] - predicted[j]) / actual[j]
      res_mae[j] = (actual[j] - predicted[j]) 
    # print (res_per)
    # print (res_mae)
    return res_per, res_mae

def mean_absolute_percentage_error(y_true, y_pred): 
    y1, y2=  percentage_error(np.asarray(y_true), np.asarray(y_pred))
    y_per=  np.mean(np.abs(y1)) * 100
    y_mae=  np.mean(np.abs(y2))
    return y_per, y_mae


# In[11]:


for indices in range (0,3):
    param_test= target_test[:,indices]
    param_pred= target_test_pred[:,indices]
    pe_h, mae_h= mean_absolute_percentage_error(param_test, param_pred)
    print (pe_h, mae_h)
    


# In[ ]:




