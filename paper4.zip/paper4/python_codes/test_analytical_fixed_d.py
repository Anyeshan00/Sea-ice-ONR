#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd

import math
from math import log10

import scipy.io
from scipy.io import loadmat

import keras
import tensorflow as tf
from keras.models import Sequential
from keras.models import load_model
from keras.layers import Dense, Dropout, Conv1D, MaxPooling1D, GlobalMaxPooling1D
from keras import backend as K

from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt


# In[2]:


datapath= r'F:\ANYESHAN\paper4\Dataset Paper\analytical datasets\fixed'
modelname= r'inverse_d_fixed_analytictrain.h5'
statfilename= r'statistics_fixed_analytictrain_epstrain.mat'

print (f'{datapath}\{modelname}')
print (f'{datapath}\{statfilename}')



# In[3]:


model_inv_d= load_model(f'{datapath}\{modelname}')
stats= loadmat (f'{datapath}\{statfilename}')


# In[4]:


mean_in= stats["mean_in"]
std_in= stats["std_in"]
mean_out= stats["mean_out"]
std_out= stats["std_out"]


# In[5]:


print(mean_in.shape[1])


# In[6]:


# loading the test files for checking losses in epsilon and ten delta
data_test= r'dataset_fixed_analytictest6.8.mat' # Testing on different test datasets

database_test= loadmat (f'{datapath}\{data_test}')


# In[7]:


data_target_extract_test= np.array(database_test['data']) 
data_target_test= data_target_extract_test [:,-1:]
# extraction of the epsilon and the  tandelta functions from the test datasets
data_features_eps_test= data_target_extract_test[:,5:6]
data_features_tand_test= data_target_extract_test[:,7:8]
data_features_nonnorm_test= np.concatenate ((data_features_eps_test, data_features_tand_test), axis= 1) # these two features are not chosen to be normalized for now 
# extracting the  frequency data from the output features
lamb_test= data_target_extract_test[:,0]
lamb_test=  np.expand_dims(lamb_test, axis=1) #dimension matching to concatenate with the input features

# extraction of the training features, the field values (non normalized)
data_features_test_E= np.array(database_test['Ez_mag']) 
data_features_test_H= np.array(database_test['Hz_mag']) 
data_features_test= np.concatenate ((lamb_test, data_features_test_E, data_features_test_H), axis= 1) # lambda is not included in the test features

# normalization of the test dataset
data_features_norm_test = (data_features_test -mean_in ) / std_in

# adding the non normalized epsilon  and  tean delta features to the  training datasets
data_features_test= np.concatenate ((data_features_nonnorm_test, data_features_norm_test), axis= 1)


# In[8]:


# apply model on the test feature dataset
# featueres: T_ice T_water S_ice S_water eps_ice eps_water tand_ice tand_water thickness
target_test_pred = model_inv_d.predict(data_features_test)*std_out + mean_out

# observables, thickness
target_test= data_target_test


# In[9]:


print(target_test.shape[0])


# In[10]:


## checking various values and compare
idx= np.random.randint(target_test.shape[0], size=(5))
print (target_test_pred[idx])
np.set_printoptions(suppress=True)
print (target_test[idx])
np.set_printoptions(suppress=True)


# In[11]:


## functions for calculation of the percentage error
def percentage_error(actual, predicted):
    res_per = np.empty(actual.shape)
    res_mae = np.empty(actual.shape)
    for j in range(actual.shape[0]):
      res_per[j] = np.abs(actual[j] - predicted[j]) / actual[j]
      res_mae[j] = np.abs(actual[j] - predicted[j]) 
    # print (res_per)
    # print (res_mae)
    return res_per, res_mae

def mean_absolute_percentage_error(y_true, y_pred): 
    y1, y2=  percentage_error(np.asarray(y_true), np.asarray(y_pred))
    y_per=  np.mean(np.abs(y1)) * 100
    y_mae=  np.mean(np.abs(y2))
    return y_per, y_mae


# In[12]:


for indices in range (0,1):
    param_test= target_test[:,indices]
    param_pred= target_test_pred[:,indices]
    pe_h, mae_h= mean_absolute_percentage_error(param_test, param_pred)
    print (pe_h, mae_h)
    


# In[ ]:




